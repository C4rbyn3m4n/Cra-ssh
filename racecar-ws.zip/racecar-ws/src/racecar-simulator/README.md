Racecar Simulator
=================
Simulates an RC car in the MIT tunnel.

1. Run "roslaunch racecar_gazebo racecar.launch" or "roslaunch racecar_gazebo racecar_tunnel.launch"
