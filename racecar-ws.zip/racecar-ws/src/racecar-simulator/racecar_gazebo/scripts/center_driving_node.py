#!/usr/bin/python

# import the main ROS python library
from ackermann_msgs.msg import AckermannDriveStamped
from sensor_msgs.msg import LaserScan
from racecar_gazebo.msg import warning_mux
import rospy

class CenterDrivingNode:

        def __init__(self):
            global msg
            global cent_pub
            msg = warning_mux()
            rospy.Subscriber("/scan", LaserScan, self.center_detection)
            cent_pub = rospy.Publisher("/warning_mux", warning_mux, queue_size=1)
            rospy.Subscriber("/warning_mux", warning_mux,self.message_editor)

        def center_detection(self,data):
            rightTotal = 0
            for x in range(120, 240):
                if data.ranges[x] < 11:
                    rightTotal += data.ranges[x]

            leftTotal = 0
            for x in range(660, 780):
                if data.ranges[x] < 11:
                    leftTotal += data.ranges[x]

            if(rightTotal>leftTotal):
                msg.distance = 1
            else:
                msg.distance = 0

            cent_pub.publish(msg)

        def message_editor(self,data):
            msg.wall_detected = data.wall_detected
            msg.object_detected = data.object_detected


if __name__ == "__main__":
    try:
        rospy.init_node("center_detection_node")
        node = CenterDrivingNode()
        rospy.loginfo("Node 'center_detection' started.")
        rospy.spin()
    except rospy.ROSInterruptException:
        pass

