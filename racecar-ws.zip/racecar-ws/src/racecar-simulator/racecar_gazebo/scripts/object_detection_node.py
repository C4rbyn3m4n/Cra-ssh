#!/usr/bin/python

# import the main ROS python library
from ackermann_msgs.msg import AckermannDriveStamped
from sensor_msgs.msg import LaserScan
from racecar_gazebo.msg import warning_mux
import rospy

class ObjectDetectionNode:
    # class constructor; subscribe to topics and advertise intent to publish
    # def __init__(self):
    #     global accel_pub
    #     global msg
    #     msg = AckermannDriveStamped()
    #     rospy.Timer(rospy.Duration(.05),self.publish_callback)
    #     accel_pub = rospy.Publisher("/vesc/ackermann_cmd_mux/input/teleop", AckermannDriveStamped, queue_size=1)
    #     rospy.Subscriber("/scan", LaserScan, self.object_detection)
    #     #self.listener()
    #     msg.header.seq = 0
    #     msg.header.stamp = rospy.Time.now()
    #     msg.header.frame_id = ''
    #     msg.drive.steering_angle = 0.0
    #     msg.drive.steering_angle_velocity = 0.0
    #     msg.drive.speed = 30.0
    #     msg.drive.acceleration = 0.0
    #     msg.drive.jerk = 0.0
    # def publish_callback(self, event):
    #     accel_pub.publish(msg)
    #
    # def listener(self):
    #     rospy.Subscriber("/scan", LaserScan, self.object_detection)
    #
    # def object_detection(self,data):
    #     for x in range(420,661):
    #         if(data.ranges[x]<2):
    #             #rospy.loginfo("Object detection found! Lidar Range @ %d: %s", x, data.ranges[x])
    #             msg.drive.speed = 0.0
    #             accel_pub.publish(msg)
    #             #rospy.loginfo("\n")
        def __init__(self):
            global msg
            global object_pub
            msg = warning_mux()
            rospy.Subscriber("/scan", LaserScan, self.object_detection)
            object_pub = rospy.Publisher("/warning_mux", warning_mux, queue_size=1)
            rospy.Subscriber("/warning_mux", warning_mux,self.message_editor)

        def object_detection(self,data):
            self.object = 0
            for x in range(420, 661):
                if(data.ranges[x]<2):
                    self.object = self.object + 1
            if self.object > 10:
                msg.object_detected = 1
            else:
                msg.object_detected = 0
            object_pub.publish(msg)


        def message_editor(self,data):
            #msg = data
            msg.wall_detected = data.wall_detected
            msg.distance = data.distance
            #print(msg)


if __name__ == "__main__":
    #msg = AckermannDriveStamped()
    #accel_pub = rospy.Publisher("/vesc/ackermann_cmd_mux/input/teleop", AckermannDriveStamped, queue_size=1)
    try:
        rospy.init_node("object_detection_node")
        node = ObjectDetectionNode()
        rospy.loginfo("Node 'object_detection' started.")
        rospy.spin()
    except rospy.ROSInterruptException:
        pass
