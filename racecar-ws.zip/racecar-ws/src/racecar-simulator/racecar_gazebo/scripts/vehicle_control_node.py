#!/usr/bin/python

from ackermann_msgs.msg import AckermannDriveStamped
from racecar_gazebo.msg import warning_mux
import rospy

class VehicleControlNode:
    def __init__(self):
        global veh_pub
        global msg
        msg = AckermannDriveStamped()
        rospy.Timer(rospy.Duration(.5),self.publish_callback)
        veh_pub = rospy.Publisher("/vesc/ackermann_cmd_mux/input/teleop", AckermannDriveStamped, queue_size=1)
        rospy.Subscriber("/warning_mux", warning_mux, self.steering_instruction)
        msg.header.seq = 0
        msg.header.stamp = rospy.Time.now()
        msg.header.frame_id = ''
        msg.drive.steering_angle = 0.0
        msg.drive.steering_angle_velocity = 0.0
        msg.drive.speed = 0.0
        msg.drive.acceleration = 0.0
        msg.drive.jerk = 0.0

    def publish_callback(self,event):
        veh_pub.publish(msg)

    def steering_instruction(self,data):
        if data.object_detected:
            msg.drive.speed = 0.0
        elif not data.object_detected:
            msg.drive.speed = 2.0
        if data.wall_detected:
            msg.drive.steering_angle = 0.5
            veh_pub.publish(msg)
            msg.drive.steering_angle = 0.0
            veh_pub.publish(msg)
        if data.distance:
            msg.drive.steering_angle = -2.0
            veh_pub.publish(msg)
            msg.drive.steering_angle = 0.0
            veh_pub.publish(msg)
        if not data.distance:
            msg.drive.steering_angle = 2.0
            veh_pub.publish(msg)
            msg.drive.steering_angle = 0.0
            veh_pub.publish(msg)

        #if not data.wall_detected and not data.distance:
        #    msg.drive.steering_angle = 0.0
	

if __name__ == "__main__":
    try:
        rospy.init_node("vehicle_control_node")
        node = VehicleControlNode()
        rospy.loginfo("Node 'vehicle control' started.")
        rospy.spin()
    except rospy.ROSInterruptException:
        pass
