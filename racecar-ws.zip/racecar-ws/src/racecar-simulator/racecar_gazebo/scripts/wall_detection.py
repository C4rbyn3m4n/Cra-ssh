#!/usr/bin/python

# import the main ROS python library
from ackermann_msgs.msg import AckermannDriveStamped
from sensor_msgs.msg import LaserScan
from racecar_gazebo.msg import warning_mux
import rospy

class WallDetectionNode:

        def __init__(self):
            global msg
            global wall_pub
            msg = warning_mux()
            rospy.Subscriber("/scan", LaserScan, self.wall_detection)
            wall_pub = rospy.Publisher("/warning_mux", warning_mux, queue_size=1)
            rospy.Subscriber("/warning_mux", warning_mux,self.message_editor)

        def wall_detection(self,data):
            self.wall = 0
            self.distance = 0
            for x in range(0, 420):
                if(data.ranges[x]<0.8):
                    self.wall = 1
            if self.wall:
                msg.wall_detected = 1
            else:
                msg.wall_detected = 0

            for x in range(0, 420):
                if(data.ranges[x]>1.0):
                    self.distance = 1
            if self.distance:
                msg.distance = 1
            else:
                msg.distance = 0
            if self.wall:
                msg.distance = 0
            wall_pub.publish(msg)

        def message_editor(self,data):
            msg.object_detected = data.object_detected


if __name__ == "__main__":
    try:
        rospy.init_node("wall_detection_node")
        node = WallDetectionNode()
        rospy.loginfo("Node 'wall_detection' started.")
        rospy.spin()
    except rospy.ROSInterruptException:
        pass
